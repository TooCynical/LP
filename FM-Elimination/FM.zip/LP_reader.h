#include <stdio.h>
#include <stdlib.h>

int read_LP(const char*, int*, int*, 
			double***, double**, double**);
